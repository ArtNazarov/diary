<?php

define("dbname", '');
define("dbuser", "");
define("dbpass", '');
define("dbhost", 'localhost');
?>